A Pen created at CodePen.io. You can find this one at https://codepen.io/NickyCDK/pen/aNvZGV.

 A quick demo of a Slick Slider with a custom navigation