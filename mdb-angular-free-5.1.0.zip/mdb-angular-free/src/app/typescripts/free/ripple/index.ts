export { RippleDirective } from './ripple-effect.directive';
export { RippleModule } from './ripple.module';
