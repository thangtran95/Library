import { Component } from '@angular/core';

@Component({
    selector: "about",
    templateUrl: './about.component.html',
    
})

export class AboutComponent{
    arrWelcome = [
        { id: 1, title: "Welcome To HBBS Group", content: "Pellentesque bibendum. Cras porttitor. Don cursus ante et vulputate feugiat mil justo faucibusn sd Integad elemen tuma volutpat vestibulum enim mi tincidunt. Lorem ipsum dolor sit amet, consectetur adipisicing elit sed do eiusmod tempor incidanaut labore et dolore.dipisicing elit sed do eiusmod tempor incidanaut labore et. Congue elit non semper laoreet sed lectus orcil posuer nisl tempor se felis pelentesque inyd urna. Integer vitae felis vel magna posu dul vestibulum. Nam rutrumc diam. Aliquam males uada maurs etulg metu Curabitur laoreet convallis nisal.", img: "assets/public/img/volkan-olmez-1352-unsplash.jpg" },
        
      ];

    arrMisVis = [
        { id: 1, title: "Mission Statement", desc: "ipsum dolor sit amet consecter adipsicing elit sed usm tempor incididunt ute labore et dolore magna aliqua ut enima minim beniaps quis nostrual exercitationullamco laboris aliqua exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate"},
        { id: 2, title: "Vission Statement", desc: "ipsum dolor sit amet consecter adipsicing elit sed usm tempor incididunt ute labore et dolore magna aliqua ut enima minim beniaps quis nostrual exercitationullamco laboris aliqua exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate"}
    ]
}