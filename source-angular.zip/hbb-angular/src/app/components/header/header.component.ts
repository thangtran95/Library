import { Component } from '@angular/core'

@Component ({
    selector: "headerpg",
    templateUrl: './header.component.html'
})

export class HeaderComponent{}