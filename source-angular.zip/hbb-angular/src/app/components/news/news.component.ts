import { Component } from '@angular/core';

@Component({
    selector: "news",
    templateUrl: './news.component.html'
})

export class NewsComponent{
    arrayNews = [
        { id: 1, img: "assets/public/img/news-11.png", title: "IOS 11 iPhone GUI", desc: "Origami, Sketch, Framer, and Photoshop templates of GUI elements found in the public release of iOS 11." },
        { id: 2, img: "assets/public/img/news-12.png", title: "Devices", desc: "Images and Sketch files of popular devices."  },
        { id: 3, img: "assets/public/img/news-13.png", title: "Desktop Kit", desc: "Sketch Template of UI Elements Found in macOS." },
        { id: 4, img: "assets/public/img/news-14.png", title: "Messenger Platform Design Kit" , desc: "Sketch templates for native experiences." },
        { id: 5, img: "assets/public/img/news-15.png", title: "iOS 10 iPhone GUI", desc: "Sketch, Photoshop, Figma, XD and Craft templates of GUI elements found in the public release of iOS 10." },
        { id: 6, img: "assets/public/img/news-16.png", title: "Diverse Device Hands", desc: "Photos of hands holding various phones, to be used in any presentation of your designs."  }
    ]
}