import { Component } from '@angular/core';

@Component({
    selector: "contact",
    templateUrl: './contact.component.html'
})

export class ContactComponent{
    arrMap = [
        {id: 1, address: "1740 Broadway, New York NY 10019", phone: "028 225 324 89", mail: "info@hbbsgroup.com"},
        {id: 2, address: "1 Austin Rd W, West Kowloon, Hong Kong", phone: "028 225 324 89", mail: "info@hbbsgroup.com"},
        {id: 3, address: "1489 Nguyen Van Linh, Tan Phong Ward, District 7, Ho Chi Minh, Vietnam", phone: "028 225 324 89", mail: "info@hbbsgroup.com"}
    ]
}