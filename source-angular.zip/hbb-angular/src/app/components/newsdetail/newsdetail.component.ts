import { Component } from '@angular/core';

@Component ({
    selector: "news-detail",
    templateUrl: './newsdetail.component.html'
})

export class NewsDetailComponent{
    
}