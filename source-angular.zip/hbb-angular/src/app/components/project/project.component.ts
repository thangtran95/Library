import { Component } from '@angular/core';

@Component ({
    selector: "project",
    templateUrl: './project.component.html'
})

export class ProjectComponent{


    arrProject = [
        { id: 1, data: "web",img: "assets/public/img/g1.jpg", title: "A2Z Trading", desc: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua." },
        { id: 2, data: "web apps",img: "assets/public/img/g2.jpg", title: "EMEMBERSHIP" , desc: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua." },
        { id: 3, data: "design",img: "assets/public/img/g3.jpg", title: "NGV247", desc: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua." },
        { id: 4, data: "apps marketing",img: "assets/public/img/g4.jpg", title: "SCB BANK" , desc: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua." },
        { id: 5, data: "web marketing",img: "assets/public/img/g5.jpg", title: "Yakson Beauty", desc: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua." },
        { id: 6, data: "apps",img: "assets/public/img/g6.jpg", title: "Chicken", desc: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor incididunt ut labore et dolore magna aliqua."  }
      ];
}