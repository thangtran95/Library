import { Component } from '@angular/core';

@Component ({
    selector: "business",
    templateUrl: './business.component.html'
})

export class BusinessComponent{
    arrSocial = [
        { id: 1, img: "assets/public/img/facebook-2.png", title: "Social Network", desc: "Many social applications with videos and images such as Beat, Vines, Instagram,…"},
        { id: 2, img: "assets/public/img/google.png", title: "Maps & Navigation", desc: "Many navigation applications such as Google Maps, Uber, Grab…"},
        { id: 3, img: "assets/public/img/whatsapp.png", title: "Chats & Calls", desc: "Many messaging applications with audio and video calls such as Whatapps, Zalo, Skype…"},
        { id: 4, img: "assets/public/img/snapchat.png", title: "Camera & Recording", desc: "Many recording applications like Snapchat, Umbala, Muvik..."},
        { id: 5, img: "assets/public/img/ebay.png", title: "E-commerce", desc: "Many business application specialized for e-commerce like Zalora, Lazada, Shopee,..."},
        { id: 6, img: "assets/public/img/spotify.png", title: "Musics & Videos", desc: "Many music player applications like Apple Music, Spotify, Zing MP3,..."}
    ]
}