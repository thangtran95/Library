import { Component } from '@angular/core';
import {Observable} from 'rxjs/Rx';


import { HttpClient, HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Component({
    selector: "home",
    templateUrl: './home.component.html'

})


export class HomeComponent{
  constructor(private http:HttpClient) {}
  
    // Uses http.get() to load data from a single API endpoint
    getTest() {
        return this.http.get('https://reqres.in/api/users?page=2');
    }

    ngOnInit() {
      this.getTest1();
    }
    public testData;
    getTest1() {
      this.getTest().subscribe(
        data => {
          this.testData = data;
        },
        err => console.error(err),
        () => console.log(this.testData)
      );
    }

    arrWeDo = [
        { id: 1, img: "assets/public/img/w-1.png", title: "Web Development", desc: "Distinctively aggregate enter prise-wide technologies"  },
        { id: 2, img: "assets/public/img/w-2.png", title: "Ux Design", desc: "Distinctively aggregate enter prise-wide technologies"  },
        { id: 3, img: "assets/public/img/w-3.png", title: "Apps Development", desc: "Distinctively aggregate enter prise-wide technologies"  },
        { id: 4, img: "assets/public/img/w-4.png", title: "Digital Marketing", desc: "Distinctively aggregate enter prise-wide technologies"  }
      ];

      arrProject = [
        { id: 1, img: "assets/public/img/project-1.jpg", title: "Web Development", desc: "Distinctively aggregate enter prise-wide technologies"  },
        { id: 2, img: "assets/public/img/project-2.jpg", title: "Ux Design", desc: "Distinctively aggregate enter prise-wide technologies"  }
      ];

      arrCount = [
        { id: 1, num: "124", title: "Satified Clients" },
        { id: 2, num: "120", title: "Satified Clients"  },
        { id: 3, num: "20", title: "Team Members" },
        { id: 4, num: "240", title: "Post in Medium"  }
      ];

      arrNews = [
        { id: 1, img: "assets/public/img/news-1.jpg", cate: "Design Thinking", title: "How Should You Think Before Starting a Project." },
        { id: 2, img: "assets/public/img/news-2.jpg", cate: "Coding", title: "How Vue.js Become popular in 2018. so much productive." },
        { id: 3, img: "assets/public/img/news-3.jpg", cate: "General", title: "10 Tools who can make you so much productive." },
      ];

      arrSlidePage = [
        { id: 1, img: "assets/public/img/logo-hbbgroup.png" },
        { id: 2, img: "assets/public/img/logo-ngv24.png" },
        { id: 3, img: "assets/public/img/logo-a2z.png" },
        { id: 4, img: "assets/public/img/logo-emember.png"  }
      ];

      arrCustomer = [
        { id: 1, title: "Great design", desc: "We love what they have done on our project. Everything is simple, clean and great. We really love the design philosophy at Zyncas.", avar: "assets/public/img/avar-1.png", name: "Raymond Turner", regency: "CEO - Keysoft" },
        { id: 2, title: "Awesome support", desc: "24/7 support even out of the working time. I highly appreciate their efforts to Agata, we have a memorable time together." , avar: "assets/public/img/avar-2.png", name: "Vanessa Gibbs", regency: "Site Manager - Agata Inc." },
        { id: 3, title: "Incredible performance", desc: "We can't believe it, the whole system just works. A huge database on our system is really a nightmare, but everything is fine now with Zyncas.", avar: "assets/public/img/avar-3.png", name: "Bruce Sutton", regency: "CTO - Appsperia" },
      ];
    

    
}

