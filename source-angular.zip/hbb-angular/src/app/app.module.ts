
import { NgModule } from '@angular/core';
import { BrowserModule }        from '@angular/platform-browser';
import { FormsModule }          from '@angular/forms';
import { appRouterModule} from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
// import { Routes, RouterModule} from '@angular/router';

// const routesConfig: Routes = [
//   { path: 'home' , component: HomeComponent },
//   { path: 'about' , component: AboutComponent }
// ]


import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { HomeComponent } from './components/home/home.component';
import { AboutComponent } from './components/about/about.component';
import { NewsComponent } from './components/news/news.component';
import { NewsDetailComponent } from './components/newsdetail/newsdetail.component';
import { ProjectComponent } from './components/project/project.component';
import { BusinessComponent } from './components/business/business.component';
import { ContactComponent } from './components/contact/contact.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    NewsComponent,
    AboutComponent,
    NewsDetailComponent,
    ProjectComponent,
    BusinessComponent,
    ContactComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    appRouterModule,
    HttpClientModule
    ],
    providers: [HomeComponent],
    bootstrap: [AppComponent]
})
export class AppModule {

 }
