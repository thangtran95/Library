import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { AboutComponent } from './components/about/about.component';
import { NewsComponent } from './components/news/news.component';
import { NewsDetailComponent } from './components/newsdetail/newsdetail.component';
import { ProjectComponent } from './components/project/project.component';
import { BusinessComponent } from './components/business/business.component';
import { ContactComponent } from './components/contact/contact.component';



const routes: Routes = [
    { path: 'home',  component: HomeComponent },
    { path: 'about',  component: AboutComponent },
    { path: 'news',  component: NewsComponent },
    { path: 'newsdetail',  component: NewsDetailComponent },
    { path: 'project',  component: ProjectComponent },
    { path: 'business',  component: BusinessComponent },
    { path: 'contact',  component: ContactComponent },
    
    {
    path: '',
    redirectTo: '/home',
    pathMatch: 'full'
    },
];

export const appRouterModule = RouterModule.forRoot(routes);